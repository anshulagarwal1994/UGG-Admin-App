export class Address {
	street: string;
	state: string;
	city: string;
	country:string;
	zipcode: string;
	latitude: string;
	longitude: string;
}