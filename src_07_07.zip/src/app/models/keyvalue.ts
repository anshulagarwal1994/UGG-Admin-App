export class KeyValue {
	constructor(){
		
	}
	Key:string;
    Value:string;
}