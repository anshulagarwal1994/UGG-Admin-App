export enum IndexedDB {
  dbName = 'PermissionDB',
  dbVersion = 1,
  storeName = 'permission',
  id = 'id',
  SiteOperator = 'Site_Operator',
  Distributor = 'Distributor',
  Technician = 'Technician'
}
