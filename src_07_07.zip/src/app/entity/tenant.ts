export interface Tenant {
}
