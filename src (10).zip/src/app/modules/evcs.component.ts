/**
 * This it the evcs root component
 */
import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'app-tenant-user',
	templateUrl: './evcs.component.html',
	styleUrls: ['./evcs.component.css']
})
export class EVCSComponent implements OnInit {

	constructor() { }

	ngOnInit(): void {
	}

}
