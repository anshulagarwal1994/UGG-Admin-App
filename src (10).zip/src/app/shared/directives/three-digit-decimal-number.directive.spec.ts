import { ThreeDigitDecimalNumberDirective } from './three-digit-decimal-number.directive';

describe('ThreeDigitDecimalNumberDirective', () => {
  it('should create an instance', () => {
    const directive = new ThreeDigitDecimalNumberDirective();
    expect(directive).toBeTruthy();
  });
});
