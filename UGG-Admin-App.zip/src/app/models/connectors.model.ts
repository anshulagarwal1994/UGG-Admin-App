export class Connectors {
    id:number;
    name:string;
    status:string;
    lastStatusTime:string;
    lastMeterTime:string;
    meter:number;
    authorizationCode:string;
}