export class Popup {
    validationMessage:string;
    url:string = '';
}